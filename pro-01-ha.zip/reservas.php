<?php include_once('header.php'); ?>
<?php 

	//reservas.php

 ?>
<?php include('footer.php'); ?>