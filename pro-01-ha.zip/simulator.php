<?php include_once('header.php'); ?>
<?php 
	//simulator.php
 ?>
<?php include('footer.php'); ?>